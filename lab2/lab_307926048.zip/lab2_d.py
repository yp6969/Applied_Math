import numpy as np
import matplotlib.pyplot as plt


comx = 2+55j
print(comx * comx.conjugate())